package Main;

public class Ville {
	
	private long id_Ville;
	private String nom;
}
