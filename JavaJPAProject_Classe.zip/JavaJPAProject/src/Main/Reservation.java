package Main;

import java.util.Date;

public class Reservation {
	
		private long id_Reservation;
		private Date date;
		private int numero;
}
