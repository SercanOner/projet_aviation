package Main;

public class Client {
		
		private long id_Client;
		private String nom;
		private int  numeroTel;
		private int numeroFax;
		private String email;
}
