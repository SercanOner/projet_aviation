package Main;

import java.util.Date;

public class Escale {
	
	private Date heureDepart;
	private Date heureArrivee;

}
