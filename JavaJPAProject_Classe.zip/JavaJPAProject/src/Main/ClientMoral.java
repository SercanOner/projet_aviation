package Main;

public class ClientMoral<TitreMoral> {
	
		private TitreMoral titre;
		private String siret;
}
