package Main;

public class Login {
	
	private long id_Login;
	private String login;
	private String motDePasse;
	private boolean admin;
	

}
