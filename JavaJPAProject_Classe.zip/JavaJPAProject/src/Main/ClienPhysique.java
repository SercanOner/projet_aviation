package Main;

public class ClienPhysique<TitrePhysique> {
	private TitrePhysique titre;
	private String prenom;

}
