package Main;

public class Aeroport {
	private long id_Aeroport;
	private String nom_Aeroport;

}
