package Main;

public class CompagnieAerienne {
	
	private long id_CompagnieAerienne;
	private String nom;

}
