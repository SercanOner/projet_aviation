package Main;

public class ClientEI<TitrePhysique> {

	private TitrePhysique titre;
	private String prenom;
}
