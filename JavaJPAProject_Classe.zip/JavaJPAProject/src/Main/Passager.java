package Main;

public class Passager {
	private long id_Passager;
	private String nom;
	private String prenom;
}
