package Main;

public class CompagnieAerienneVol {
	
		private String numero;
}
