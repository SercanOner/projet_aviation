package Main;

public class Adresse {

	private String adresse;
	private String codePostal;
	private String ville;
	private String pays;
}
