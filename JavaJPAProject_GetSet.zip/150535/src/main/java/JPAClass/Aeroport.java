package JPAClass;

public class Aeroport {
	private long id_Aeroport;
	private String nom_Aeroport;
	
	public long getId_Aeroport() {
		return id_Aeroport;
	}
	public void setId_Aeroport(long id_Aeroport) {
		this.id_Aeroport = id_Aeroport;
	}
	public String getNom_Aeroport() {
		return nom_Aeroport;
	}
	public void setNom_Aeroport(String nom_Aeroport) {
		this.nom_Aeroport = nom_Aeroport;
	}

}
