package JPAClass;

import java.util.Date;

public class Escale {
	
	private Date heureDepart;
	private Date heureArrivee;
	
	public Escale(){
		
	}

	public Date getHeureDepart() {
		return heureDepart;
	}

	public void setHeureDepart(Date heureDepart) {
		this.heureDepart = heureDepart;
	}

	public Date getHeureArrivee() {
		return heureArrivee;
	}

	public void setHeureArrivee(Date heureArrivee) {
		this.heureArrivee = heureArrivee;
	}
	

}
