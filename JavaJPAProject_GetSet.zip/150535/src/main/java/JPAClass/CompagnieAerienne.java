package JPAClass;

public class CompagnieAerienne {
	
	private long id_CompagnieAerienne;
	private String nom;
	public CompagnieAerienne(){
		
	}
	public long getId_CompagnieAerienne() {
		return id_CompagnieAerienne;
	}
	public void setId_CompagnieAerienne(long id_CompagnieAerienne) {
		this.id_CompagnieAerienne = id_CompagnieAerienne;
	}
	public String getNom() {
		return nom;
	}
	public void setNom(String nom) {
		this.nom = nom;
	}
	

}
