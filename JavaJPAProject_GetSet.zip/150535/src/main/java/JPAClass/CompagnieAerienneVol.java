package JPAClass;

public class CompagnieAerienneVol {
	
		private String numero;
		
		public CompagnieAerienneVol(){
			
		}

		public String getNumero() {
			return numero;
		}

		public void setNumero(String numero) {
			this.numero = numero;
		}
		
		
}
