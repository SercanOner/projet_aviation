package JPAClass;

public class Ville {
	
	private long id_Ville;
	private String nom;
	
	public Ville(){
		
	}

	public long getId_Ville() {
		return id_Ville;
	}

	public void setId_Ville(long id_Ville) {
		this.id_Ville = id_Ville;
	}

	public String getNom() {
		return nom;
	}

	public void setNom(String nom) {
		this.nom = nom;
	}
	
}
